package com.example.shaderoverlay

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.opengl.GLSurfaceView
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.*

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private val views = mutableListOf<View>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ch = "shader"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Shader overlay", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, ch).setContentTitle("Shader overlay работает")
            .setSmallIcon(android.R.drawable.ic_menu_view).build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        @Suppress("DEPRECATION") val data = i?.getParcelableExtra<Intent>("data") ?: run { stopSelf(); return START_NOT_STICKY }
        projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
        projection!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, Handler(Looper.getMainLooper()))

        wm = getSystemService(WindowManager::class.java)
        val b = wm.maximumWindowMetrics.bounds
        val dpi = resources.displayMetrics.densityDpi

        lateinit var gl: GLSurfaceView
        val renderer = ShaderRenderer(b.width(), b.height(),
            onSurface = { s -> vd = projection!!.createVirtualDisplay("cap", b.width(), b.height(), dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, s, null, null) },
            requestRender = { gl.requestRender() })
        gl = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2); setRenderer(renderer); renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
        }
        // Фильтр на весь экран: касания проходят насквозь в игру.
        // FLAG_SECURE нужен, чтобы захват не снимал сам оверлей (иначе петля обратной связи).
        val full = LP(LP.MATCH_PARENT, LP.MATCH_PARENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS or LP.FLAG_SECURE,
            PixelFormat.TRANSLUCENT)
        wm.addView(gl, full); views += gl

        addMenu(renderer)
        return START_NOT_STICKY
    }

    private fun addMenu(r: ShaderRenderer) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.argb(210, 20, 20, 20)); setPadding(24, 16, 24, 16); visibility = View.GONE
        }
        fun slider(name: String, max: Int, init: Float, scale: Float, set: (Float) -> Unit) {
            panel.addView(TextView(this).apply { text = name; setTextColor(Color.WHITE) })
            panel.addView(SeekBar(this).apply {
                this.max = max; progress = (init / scale).toInt()
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { set(p * scale) }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }, LinearLayout.LayoutParams(600, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        slider("Резкость", 100, r.sharp, 0.01f) { r.sharp = it }
        slider("Контраст", 100, r.contrast, 0.02f) { r.contrast = it }
        slider("Насыщенность", 100, r.sat, 0.02f) { r.sat = it }
        slider("Виньетка", 100, r.vig, 0.01f) { r.vig = it }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(Button(this).apply { text = "⚙"; setOnClickListener {
            panel.visibility = if (panel.visibility == View.GONE) View.VISIBLE else View.GONE } })
        root.addView(panel)
        val lp = LP(LP.WRAP_CONTENT, LP.WRAP_CONTENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_SECURE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }
        wm.addView(root, lp); views += root
    }

    override fun onDestroy() {
        views.forEach { runCatching { wm.removeView(it) } }
        vd?.release(); projection?.stop()
        super.onDestroy()
    }
}
