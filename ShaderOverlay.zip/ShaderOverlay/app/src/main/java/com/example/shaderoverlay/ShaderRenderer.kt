package com.example.shaderoverlay

import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class ShaderRenderer(
    private val w: Int, private val h: Int,
    private val onSurface: (Surface) -> Unit,
    private val requestRender: () -> Unit
) : GLSurfaceView.Renderer {

    // Параметры шейдера (меняются из меню)
    @Volatile var sharp = 0.4f
    @Volatile var contrast = 1.1f
    @Volatile var sat = 1.2f
    @Volatile var vig = 0.0f

    private var tex = 0; private var prog = 0
    private lateinit var st: SurfaceTexture
    private val mat = FloatArray(16)
    private val quad = floatArrayOf(-1f,-1f,0f,0f, 1f,-1f,1f,0f, -1f,1f,0f,1f, 1f,1f,1f,1f)
    private val buf = ByteBuffer.allocateDirect(quad.size * 4).order(ByteOrder.nativeOrder())
        .asFloatBuffer().apply { put(quad); position(0) }

    private val vs = """
        attribute vec2 p; attribute vec2 uv; uniform mat4 m; varying vec2 v;
        void main(){ gl_Position = vec4(p,0.,1.); v = (m*vec4(uv,0.,1.)).xy; }"""
    private val fs = """
        #extension GL_OES_EGL_image_external : require
        precision mediump float;
        varying vec2 v; uniform samplerExternalOES t; uniform vec2 px;
        uniform float sharp, contrast, sat, vig;
        void main(){
            vec3 c = texture2D(t,v).rgb;
            vec3 b = texture2D(t,v+vec2(px.x,0.)).rgb + texture2D(t,v-vec2(px.x,0.)).rgb
                   + texture2D(t,v+vec2(0.,px.y)).rgb + texture2D(t,v-vec2(0.,px.y)).rgb;
            c += (c*4. - b) * sharp;
            c = (c-.5)*contrast + .5;
            float l = dot(c, vec3(.299,.587,.114));
            c = mix(vec3(l), c, sat);
            c *= 1. - vig * smoothstep(.3,.8,distance(v,vec2(.5)));
            gl_FragColor = vec4(clamp(c,0.,1.),1.);
        }"""

    override fun onSurfaceCreated(g: GL10?, c: EGLConfig?) {
        val t = IntArray(1); GLES20.glGenTextures(1, t, 0); tex = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        st = SurfaceTexture(tex).apply {
            setDefaultBufferSize(w, h)
            setOnFrameAvailableListener { requestRender() }
        }
        prog = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, compile(GLES20.GL_VERTEX_SHADER, vs))
            GLES20.glAttachShader(it, compile(GLES20.GL_FRAGMENT_SHADER, fs))
            GLES20.glLinkProgram(it)
        }
        onSurface(Surface(st))
    }

    override fun onSurfaceChanged(g: GL10?, W: Int, H: Int) = GLES20.glViewport(0, 0, W, H)

    override fun onDrawFrame(g: GL10?) {
        st.updateTexImage(); st.getTransformMatrix(mat)
        GLES20.glUseProgram(prog)
        val pl = GLES20.glGetAttribLocation(prog, "p"); val ul = GLES20.glGetAttribLocation(prog, "uv")
        buf.position(0); GLES20.glVertexAttribPointer(pl, 2, GLES20.GL_FLOAT, false, 16, buf); GLES20.glEnableVertexAttribArray(pl)
        buf.position(2); GLES20.glVertexAttribPointer(ul, 2, GLES20.GL_FLOAT, false, 16, buf); GLES20.glEnableVertexAttribArray(ul)
        GLES20.glUniformMatrix4fv(loc("m"), 1, false, mat, 0)
        GLES20.glUniform2f(loc("px"), 1f / w, 1f / h)
        GLES20.glUniform1f(loc("sharp"), sharp); GLES20.glUniform1f(loc("contrast"), contrast)
        GLES20.glUniform1f(loc("sat"), sat); GLES20.glUniform1f(loc("vig"), vig)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun loc(n: String) = GLES20.glGetUniformLocation(prog, n)
    private fun compile(type: Int, src: String) = GLES20.glCreateShader(type).also {
        GLES20.glShaderSource(it, src); GLES20.glCompileShader(it)
    }
}
